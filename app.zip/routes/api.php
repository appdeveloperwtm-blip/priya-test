<?php

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;
use App\Http\Controllers\Api\AuthController;
use App\Http\Controllers\Api\UserController;
use App\Http\Controllers\Api\ClientController;
use App\Http\Controllers\Api\LeadController;
use App\Http\Controllers\Api\TicketController;
use App\Http\Controllers\Api\FollowUpController;

// Public routes
Route::post('/register', [AuthController::class, 'register']);
Route::post('/login', [AuthController::class, 'login']);

// Protected routes
Route::middleware('auth:sanctum')->group(function () {

    // Auth routes
    Route::post('/logout', [AuthController::class, 'logout']);
    Route::get('/me', [AuthController::class, 'me']);

    // User Management (Admin only)
    Route::middleware('role:admin')->group(function () {
        Route::get('/users', [UserController::class, 'index']);
        Route::get('/user-role', [UserController::class, 'role']);
        Route::post('/users', [UserController::class, 'store']);
        Route::put('/users/{user}', [UserController::class, 'update']);
        Route::delete('/users/{user}', [UserController::class, 'destroy']);
        Route::post('/users/{user}/assign-role', [UserController::class, 'assignRole']);
    });

    // Client routes
    Route::get('/clients', [ClientController::class, 'index']); // All authenticated
    Route::post('/clients', [ClientController::class, 'store']); // All authenticated
    Route::get('/clients/{client}', [ClientController::class, 'show']); // All authenticated

    // Manager & Admin can edit clients
    Route::middleware('role:admin,manager')->group(function () {
        Route::put('/clients/{client}', [ClientController::class, 'update']);
    });

    // Admin only - Delete clients
    Route::middleware('role:admin')->group(function () {
        Route::delete('/clients/{client}', [ClientController::class, 'destroy']);
    });

    // Lead routes
    Route::get('/leads', [LeadController::class, 'index']); // All authenticated
    Route::post('/leads', [LeadController::class, 'store']); // All authenticated
    Route::get('/leads/{lead}', [LeadController::class, 'show']); // All authenticated
    Route::put('/leads/{lead}', [LeadController::class, 'update']); // All authenticated

    // Manager can assign leads
    Route::middleware('role:admin,manager')->group(function () {
        Route::post('/leads/{lead}/assign', [LeadController::class, 'assignLead']);
    });

    // Admin only - Delete leads
    Route::middleware('role:admin')->group(function () {
        Route::delete('/leads/{lead}', [LeadController::class, 'destroy']);
    });

    // Ticket routes
    Route::get('/tickets', [TicketController::class, 'index']); // All authenticated
    Route::post('/tickets', [TicketController::class, 'store']); // All authenticated
    Route::get('/tickets/{ticket}', [TicketController::class, 'show']); // All authenticated
    Route::put('/tickets/{ticket}', [TicketController::class, 'update']); // Support can update

    // Admin only - Delete tickets
    Route::middleware('role:admin')->group(function () {
        Route::delete('/tickets/{ticket}', [TicketController::class, 'destroy']);
    });

    // Follow-up routes (Sales Executive)
    Route::get('/follow-ups', [FollowUpController::class, 'index']);
    Route::post('/follow-ups', [FollowUpController::class, 'store']);
    Route::get('/follow-ups/{followUp}', [FollowUpController::class, 'show']);
    Route::put('/follow-ups/{followUp}', [FollowUpController::class, 'update']);
    Route::delete('/follow-ups/{followUp}', [FollowUpController::class, 'destroy']);
});
